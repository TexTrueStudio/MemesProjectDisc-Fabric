# MemesProjectDisc-Forge

Language: EN / ZH-CN

This module is one of the MemesProject subsidiary modules. Of course, you can use it alone (because I didn't add preconditions). This module is to solve the problem of too many records in the main module. The Fabric version is in production.

### Planned to add/already added:

|                         Song                         |        Singer        |
| :--------------------------------------------------: | :------------------: |
|               Never Gonna Give You Up                |     Rick Astley      |
|                     NightVoyager                     |    不才/三体宇宙     |
|                    Shooting Stars                    |     Bag Raiders      |
|                    Bad Apple !!①                     | Alstroemeria Records |
| GoyangUburUburRemixed(Tari Ubur Ubur / DJ Ubur Ubur) |    HendroEngkeng     |
|                 フリージア(Freesia)                  |         Uru          |
|                       DEJA VU                        |     DAVE RODGERS     |
|              BadApple!!-幺乐団の歴史1②               |   上海アリス幻樂団   |



> ①:[Bad Apple!! PV【影绘】 - THBWiki · Professional Touhou Project Wiki Site - TBSGroup (thwiki.cc)](https://thwiki.cc/-/1n6f?setlang=en) 
>
> ②:[Bad Apple!! - THBWiki · Professional Touhou Project Wiki Site - TBSGroup (thwiki.cc)](https://thwiki.cc/Bad_Apple!!) 

