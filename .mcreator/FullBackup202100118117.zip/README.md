# MemesProjectDisc-Forge

Language: EN / ZH-CN

此模组为MemesProject附属模组之一，当然你可以单独使用（因为我没有给添加前置条件），此模组是为解决主模组唱片过多,Fabric版正在制作中。

### 计划加入/已加入:

|                         歌名                         |         作者         |
| :--------------------------------------------------: | :------------------: |
|               Never Gonna Give You Up                |     Rick Astley      |
|                     NightVoyager                     |    不才/三体宇宙     |
|                    Shooting Stars                    |     Bag Raiders      |
|                    Bad Apple !! ①                    | Alstroemeria Records |
| GoyangUburUburRemixed(Tari Ubur Ubur / DJ Ubur Ubur) |    HendroEngkeng     |
|                 フリージア(Freesia)                  |         Uru          |
|                       DEJA VU                        |     DAVE RODGERS     |
|              BadApple!!-幺乐団の歴史1②               |   上海アリス幻樂団   |



> ①:[Bad Apple!! PV【影绘】 - THBWiki · 专业性的东方Project维基百科 - TBSGroup (thwiki.cc)](https://thwiki.cc/-/1n6f) 
>
> ②:[Bad Apple!! - THBWiki · 专业性的东方Project维基百科 - TBSGroup (thwiki.cc)](https://thwiki.cc/Bad_Apple!!) 

